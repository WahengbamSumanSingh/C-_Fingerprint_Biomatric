﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace BCA_FinalYear_Biomatric_V1._1.DTO
{
    public class maindto
    {
        public class main_dto
        {
            private string student_name;
            private string student_ids;
            private string time;
            public string Stu_name
            {
                get { return student_name; }
                set { student_name = value; }
            }

            public string Stu_id
            {
                get { return student_ids; }
                set { student_ids = value; }
            }

            public string dat_tim
            {
                get { return time; }
                set { time = value; }
            }

            
        }
    }
}
