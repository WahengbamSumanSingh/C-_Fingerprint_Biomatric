﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BCA_FinalYear_Biomatric_V1._1.DTO
{
    public class devices_settingdto
    {
        public class device_setting
        {
            private int _ids;
            private string _device_type;
            private string _connection_type;
            private string _config_protocol;
            private string _device_name;
            private string _ip_address;
            private int _port;
            private string _company_profile;

            public int Ids
            {
                get { return _ids; }
                set { _ids = value; }
            }
            public string DeviceType
            {
                get { return _device_type; }
                set { _device_type = value; }
            }
            public string ConnectionType
            {
                get { return _connection_type; }
                set { _connection_type = value; }
            }
            public string ConfigProtocol
            {
                get { return _config_protocol; }
                set { _config_protocol = value; }
            }
            public string DeviceName
            {
                get { return _device_name; }
                set { _device_name = value; }
            }
            public string IpAddress
            {
                get { return _ip_address; }
                set { _ip_address = value; }
            }
            public int Port
            {
                get { return _port; }
                set { _port = value; }
            }
            public string CompanyProfile
            {
                get { return _company_profile; }
                set { _company_profile = value; }
            }
        
        }
    }
}
