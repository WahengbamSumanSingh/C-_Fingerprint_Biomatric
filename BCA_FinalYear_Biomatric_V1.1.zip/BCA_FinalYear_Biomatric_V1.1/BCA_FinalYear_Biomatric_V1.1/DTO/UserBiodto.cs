﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
namespace BCA_FinalYear_Biomatric_V1._1.DTO
{
    public class UserBiodto
    {
        private string _usrid;
        private string _firstname;
        private string _lastname;
        private string _curadd;
        private string _peradd;
        private Byte[] _userimg;
        private int _DeviceIds;
        public string UID
        {
            get { return _usrid; }
            set { _usrid = value; }
        }
        public string fname
        {
            get { return _firstname; }
            set { _firstname = value; }
        }
        public string lname
        {
            get { return _lastname; }
            set { _lastname = value; }
        }
        public string curadd
        {
            get { return _curadd; }
            set { _curadd = value; }
        }
        public string peradd
        {
            get { return _peradd; }
            set { _peradd = value; }
        }
        public Byte[] Uimg
        {
            get { return _userimg; }
            set { _userimg = value; }
        }
        public int devids
        {
            get { return _DeviceIds; }
            set { _DeviceIds = value; }
        }

    }
}
