﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BCA_FinalYear_Biomatric_V1._1.DTO
{
    public class registrationdto
    {
        public class user_profile
        {
            private int _id;
            private string _firstName;
            private string _lastName;
            private string _gender;
            private string _country;
            private string _state;
            private string _email;
            private string _phoneNos;
            private string _userName;
            private string _password;

            public int Id
            {

                get { return _id; }

                set { _id = value; }

            }
            public string FirstName
            {
                get { return _firstName; }
                set { _firstName = value; }
            }
            public string LastName
            {
                get { return _lastName; }
                set { _lastName = value; }
            }
            public string Gender
            {
                get { return _gender; }
                set { _gender = value; }
            }
            public string Country
            {
                get { return _country; }
                set { _country = value; }
            }
            public string State
            {
                get { return _state; }
                set { _state = value; }
            }
            public string Email
            {
                get { return _email; }
                set { _email = value; }
            }
            public string Phone_Nos
            {
                get { return _phoneNos; }
                set { _phoneNos = value; }
            }
            public string User_Name
            {
                get { return _userName; }
                set { _userName = value; }
            }
            public string PassWord
            {
                get { return _password; }
                set { _password = value; }
            }

        }

    }
}
