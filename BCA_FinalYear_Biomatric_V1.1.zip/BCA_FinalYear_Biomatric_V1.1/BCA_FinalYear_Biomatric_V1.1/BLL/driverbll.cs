﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCA_FinalYear_Biomatric_V1._1.DAL;
using BCA_FinalYear_Biomatric_V1._1.DTO;
using System.Data;

namespace BCA_FinalYear_Biomatric_V1._1.BLL
{
    public class driverbll
    {
        private driverdal Ddal = new driverdal();

        public DataTable Check_Driver_IP(int Id)
        {
            try
            {
                return Ddal.get_device_ip_port(Id);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        
        }

    }
}
