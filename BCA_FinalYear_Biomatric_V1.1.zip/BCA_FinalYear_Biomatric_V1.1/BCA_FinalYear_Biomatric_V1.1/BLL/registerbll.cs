﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCA_FinalYear_Biomatric_V1._1.DAL;
using BCA_FinalYear_Biomatric_V1._1.DTO;

namespace BCA_FinalYear_Biomatric_V1._1.BLL
{
    public class registerbll
    {
        private registerdal regisdal = new registerdal();

        public string AddUser(registrationdto.user_profile aUser)
        {
            try
            {
                return regisdal.AddUser(aUser);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public string UpdateUser(registrationdto.user_profile aUser)
        {
            try
            {
                return regisdal.UpdateUser(aUser);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public void DeleteUser(int deleteId)
        {
            try
            {
                regisdal.DeleteUsr(deleteId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
