﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using BCA_FinalYear_Biomatric_V1._1.DAL;

namespace BCA_FinalYear_Biomatric_V1._1.BLL
{
    public class loginbll
    {
        public DataTable GetLogin()
        {
            try
            {
                logindal objdal = new logindal();
                return objdal.ReadLogin();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
