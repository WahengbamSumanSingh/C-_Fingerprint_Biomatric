﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCA_FinalYear_Biomatric_V1._1.DAL;
using BCA_FinalYear_Biomatric_V1._1.DTO;
using System.Data;

namespace BCA_FinalYear_Biomatric_V1._1.BLL
{
    public class UserBiobll
    {
        private UserBiodal udal = new UserBiodal();
        public string AddUser(UserBiodto udto)
        {
            try
            {
                return udal.AddBio(udto);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable SelectIPFrmDeviceName(string SelectIds)
        {
            try
            {
                return udal.SelectIPNPortFrmDeviceName(SelectIds);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public DataTable SelectOnlyDName()
        {
            try
            {
                return udal.SelectDeviceName();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
    }
}
