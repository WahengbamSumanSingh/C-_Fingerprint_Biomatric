﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using BCA_FinalYear_Biomatric_V1._1.DAL;
using BCA_FinalYear_Biomatric_V1._1.DTO;
namespace BCA_FinalYear_Biomatric_V1._1.BLL
{
    public class mainbll
    {
        private maindal mdal = new maindal();

        public string Add_report(maindto.main_dto mdto)
        {
            try
            {
                return mdal.AddReport(mdto);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable SelectDevicesData(int ids, string user_ids)
        {
            try
            {
                return mdal.SelectMainData(ids,user_ids);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
