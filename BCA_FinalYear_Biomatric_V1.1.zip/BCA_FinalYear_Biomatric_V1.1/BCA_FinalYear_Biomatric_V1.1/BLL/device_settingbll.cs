﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using BCA_FinalYear_Biomatric_V1._1.DAL;
using BCA_FinalYear_Biomatric_V1._1.DTO;

namespace BCA_FinalYear_Biomatric_V1._1.BLL
{
    public class device_settingbll
    {
        private device_settingdal devdal = new device_settingdal();

        public string AddDevice(devices_settingdto.device_setting aDevice)
        {
            try
            {
                return devdal.AddDevices(aDevice);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string UpdateDevice(devices_settingdto.device_setting uDevice)
        {
            try
            {
                return devdal.UpdateDeviceSetting(uDevice);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void deleteDevice(int delIds)
        {
            try
            {
                devdal.DeleteDeviceSetting(delIds);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public DataTable selectDevice(int SelId)
        {
            try
            {
                return devdal.SelectDeviceSetting(SelId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable  SelectOIds()
        {
            try
            {
                return devdal.SelectOnlyIds();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string GetCheckdeviceRecurring(devices_settingdto.device_setting gcrcheck)
        {
            try
            {
                return devdal.checkReccuringDevice(gcrcheck);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
