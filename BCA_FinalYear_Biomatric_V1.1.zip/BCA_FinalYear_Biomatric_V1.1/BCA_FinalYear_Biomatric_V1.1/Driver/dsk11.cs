﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using BCA_FinalYear_Biomatric_V1._1.BLL;
using System.Data;
namespace BCA_FinalYear_Biomatric_V1._1.Driver
{
    public class dsk11
    {
        public string checkdsk11(int Id)
        {      
            try
            {

                driverbll drive = new driverbll();
                DataTable dt = drive.Check_Driver_IP(Id);
                string IP = dt.Rows[0][ 0].ToString();
                string ports = dt.Rows[0][1].ToString();
                // set the TcpListener on port 13000
                IPAddress ServerIP = IPAddress.Parse(IP);
                
                int port = Int32.Parse(ports);
                TcpListener server = new TcpListener(ServerIP, port);

                // Start listening for client requests
                server.Start();
                TcpClient client = server.AcceptTcpClient();
                
                client.Close();
                return "Connected";
               
                //Console.WriteLine("Connected!");            
                // Shutdown and end connection                             
            }
            catch(Exception ex)
            {
                return "Not Connected";
            }
            
        }
        }
        
 }
