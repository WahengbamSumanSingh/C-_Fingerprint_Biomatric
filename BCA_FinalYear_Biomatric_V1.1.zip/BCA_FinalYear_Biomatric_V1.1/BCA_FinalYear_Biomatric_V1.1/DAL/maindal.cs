﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using BCA_FinalYear_Biomatric_V1._1.DTO;

namespace BCA_FinalYear_Biomatric_V1._1.DAL
{
    public class maindal
    {
        DataTable dt = new DataTable();
        connection conn = new connection();

        public string AddReport(maindto.main_dto mdto)
        {
            int insertIds = 0;
            try
            {
                conn.con.Open();
                string sql = "INSERT INTO aten_db(stu_name,stu_ids,d_time)" +
                    "VALUES(@stuname,@stuids,@d_time)";
                SqlCommand cmd = new SqlCommand(sql, conn.con);
                cmd.Parameters.AddWithValue("stuname", mdto.Stu_name);
                cmd.Parameters.AddWithValue("stuids", mdto.Stu_id);
                cmd.Parameters.AddWithValue("d_time", mdto.dat_tim);
                insertIds = cmd.ExecuteNonQuery();
                if (insertIds > 0)
                {
                    return "success";
                }
                else
                {
                    return "Unknown error occured";
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }

        public DataTable SelectMainData(int dataIDs, string usr_ids)
        {
            try
            {
                conn.con.Open();
                SqlCommand sqlcmd = new SqlCommand("select user_ids,first_name,last_name,user_image from user_bio where device_id=@dids and user_ids=@usrids", conn.con);
                sqlcmd.Parameters.AddWithValue("dids", dataIDs);
                sqlcmd.Parameters.AddWithValue("usrids", usr_ids);
                SqlDataReader sdr = sqlcmd.ExecuteReader();
                dt.Load(sdr);
                return dt;
            }
            catch (SqlException sqlex)
            {
                throw sqlex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
    }
}
