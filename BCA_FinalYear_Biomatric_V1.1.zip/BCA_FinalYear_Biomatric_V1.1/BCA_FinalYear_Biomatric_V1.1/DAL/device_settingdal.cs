﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using BCA_FinalYear_Biomatric_V1._1.DTO;

namespace BCA_FinalYear_Biomatric_V1._1.DAL
{
    public class device_settingdal
    {
        DataTable dt = new DataTable();
        connection conn = new connection();
        public string AddDevices(devices_settingdto.device_setting dSetting)
        {
            int insertIds = 0;
            try
            {
                conn.con.Open();
                string sql = "INSERT INTO device_setting(Device_Type,Connection_Type,Config_Protocol,Device_Name,IP_Address,Port,Company_Profile)" +
                    "VALUES(@devicetype,@connectiontype,@configprotocol,@devicename,@ipaddress,@port,@companyprofile)";
                SqlCommand cmd = new SqlCommand(sql, conn.con);
                cmd.Parameters.AddWithValue("devicetype", dSetting.DeviceType);
                cmd.Parameters.AddWithValue("connectiontype", dSetting.ConnectionType);
                cmd.Parameters.AddWithValue("configprotocol", dSetting.ConfigProtocol);
                cmd.Parameters.AddWithValue("devicename", dSetting.DeviceName);
                cmd.Parameters.AddWithValue("ipaddress", dSetting.IpAddress);
                cmd.Parameters.AddWithValue("port", dSetting.Port);
                cmd.Parameters.AddWithValue("companyprofile", dSetting.CompanyProfile);

                insertIds = cmd.ExecuteNonQuery();
                if (insertIds > 0)
                {
                    return "success";
                }
                else
                {
                    return "Unknown error occured";
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
        public string UpdateDeviceSetting(devices_settingdto.device_setting udSetting)
        {
            int updateId = 0;
            try
            {
                conn.con.Open();
                SqlCommand cmd = new SqlCommand("UPDATE device_setting SET Device_Type=@devicetype,Connection_Type=@connectiontype,Config_Protocol=@configprotocol,Device_Name=@devicename,IP_Address=@ipaddress,Port=@port,Company_Profile=@companyprofile" +
                "WHERE Ids=@id", conn.con);
                cmd.Parameters.AddWithValue("devicetype", udSetting.DeviceType);
                cmd.Parameters.AddWithValue("connectiontype", udSetting.ConnectionType);
                cmd.Parameters.AddWithValue("configprotocol", udSetting.ConfigProtocol);
                cmd.Parameters.AddWithValue("devicename", udSetting.DeviceName);
                cmd.Parameters.AddWithValue("ipaddress", udSetting.IpAddress);
                cmd.Parameters.AddWithValue("port", udSetting.Port);
                cmd.Parameters.AddWithValue("companyprofile", udSetting.CompanyProfile);
                cmd.Parameters.AddWithValue("id", udSetting.Ids);
                cmd.ExecuteNonQuery();
                if (updateId > 0)
                {
                    return "success";
                }
                else
                {
                    return "Unknown error occured";
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
        public void DeleteDeviceSetting(int deleteId)
        {
            try
            {
                conn.con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM device_setting WHERE Ids = @id", conn.con);
                cmd.Parameters.AddWithValue("id", deleteId);
                cmd.ExecuteNonQuery();
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
        public DataTable SelectDeviceSetting(int SelectId)
        {
            connection conn = new connection();
            if (ConnectionState.Closed == conn.con.State)
            {
                conn.con.Open();
            }
            SqlCommand cmd = new SqlCommand("SELECT *,row_number() OVER(ORDER BY Ids) AS RowNumber From device_setting WHERE Ids = @ids", conn.con);
            cmd.Parameters.AddWithValue("ids",SelectId);
            try
            {
                SqlDataReader rd = cmd.ExecuteReader();
                dt.Load(rd);
                return dt;
            }
            catch (SqlException sqlex)
            {
                throw sqlex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
        public DataTable SelectOnlyIds()
        {
            try 
            {
                conn.con.Open();
                SqlCommand cmd = new SqlCommand("SELECT Ids FROM device_setting", conn.con);
                SqlDataReader sda = cmd.ExecuteReader();
                dt.Load(sda);
                return dt;
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
        public string checkReccuringDevice(devices_settingdto.device_setting checkRec)
        {
            try
            {
                conn.con.Open();
                SqlCommand comnd = new SqlCommand("SELECT * FROM device_setting WHERE Device_Name= @devicename AND IP_Address = @ipaddress", conn.con);
                comnd.Parameters.AddWithValue("devicename", checkRec.DeviceName);
                comnd.Parameters.AddWithValue("ipaddress", checkRec.IpAddress);
                SqlDataAdapter sda = new SqlDataAdapter(comnd);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    return "exist";
                }
                else
                {
                    return "notexist";
                }
            }
            catch (SqlException sqlex)
            {
                throw sqlex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
    }
}
