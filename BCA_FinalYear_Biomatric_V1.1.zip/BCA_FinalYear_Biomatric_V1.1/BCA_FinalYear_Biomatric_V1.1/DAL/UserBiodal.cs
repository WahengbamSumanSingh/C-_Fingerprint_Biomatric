﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using BCA_FinalYear_Biomatric_V1._1.DTO;

namespace BCA_FinalYear_Biomatric_V1._1.DAL
{
    public class UserBiodal
    {
        DataTable dt = new DataTable();
        connection conn = new connection();

        public string AddBio(UserBiodto ubio)
        {
            int AddBioID = 0;
            try
            {
                conn.con.Open();
                string sqlcmd = "INSERT INTO user_bio(user_ids,first_name,last_name,permanent_add,current_add,user_image,device_id)"
                    + "VALUES(@usrid,@firstname,@lastname,@padd,@cadd,@uimg,@divid)";
                SqlCommand cmd = new SqlCommand(sqlcmd, conn.con);
                cmd.Parameters.AddWithValue("usrid", ubio.UID);
                cmd.Parameters.AddWithValue("firstname", ubio.fname);
                cmd.Parameters.AddWithValue("lastname", ubio.lname);
                cmd.Parameters.AddWithValue("padd", ubio.peradd);
                cmd.Parameters.AddWithValue("cadd", ubio.curadd);
                cmd.Parameters.AddWithValue("uimg", ubio.Uimg);
                cmd.Parameters.AddWithValue("divid", ubio.devids);
                AddBioID = cmd.ExecuteNonQuery();
                if (AddBioID > 0)
                {
                    return "success";
                }
                else
                {
                    return "Unknown error occured";
                }
            }
            catch (SqlException sqlex)
            {
                throw sqlex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }

        public DataTable SelectDeviceName()
        {
            try
            {
                conn.con.Open();
                SqlCommand cmd = new SqlCommand("Select Ids from device_setting",conn.con);
                SqlDataReader sda = cmd.ExecuteReader();
                dt.Load(sda);
                return dt;
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }

        public DataTable SelectIPNPortFrmDeviceName(string name)
        {
            try
            {
                int id = Int32.Parse(name);
                conn.con.Open();
                SqlCommand sqlcmd = new SqlCommand("Select IP_Address,Port from device_setting where Ids=@dname",conn.con);
                sqlcmd.Parameters.AddWithValue("dname",id);
                SqlDataReader sdr = sqlcmd.ExecuteReader();
                dt.Load(sdr);
                return dt;
            }
            catch (SqlException sqlex)
            {
                throw sqlex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
    }
}
