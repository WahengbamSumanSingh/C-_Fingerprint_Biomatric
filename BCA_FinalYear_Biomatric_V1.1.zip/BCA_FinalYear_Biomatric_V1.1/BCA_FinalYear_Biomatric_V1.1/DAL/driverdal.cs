﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using BCA_FinalYear_Biomatric_V1._1.DTO;

namespace BCA_FinalYear_Biomatric_V1._1.DAL
{
    public class driverdal
    {
        connection conn = new connection();
        DataTable dt = new DataTable();
        public DataTable get_device_ip_port(int SelectID)
        {
            try
            {
                conn.con.Open();
                SqlCommand cmd = new SqlCommand("select IP_Address,Port from device_setting where Ids = @ids;",conn.con);
                cmd.Parameters.AddWithValue("ids", SelectID);
                SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                return dt;
            }
            catch (SqlException sqlex)
            {
                throw sqlex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }          
            }
        
        }
    }
}
