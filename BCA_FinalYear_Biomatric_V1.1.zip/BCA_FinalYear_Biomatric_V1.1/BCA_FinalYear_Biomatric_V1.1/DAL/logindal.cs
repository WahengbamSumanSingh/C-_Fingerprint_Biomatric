﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BCA_FinalYear_Biomatric_V1._1.DAL
{
    public class logindal
    {
        DataTable dt = new DataTable();
        public DataTable ReadLogin()
        {
            connection conn = new connection();
            if (ConnectionState.Closed == conn.con.State)
            {
                conn.con.Open();
            }
            SqlCommand cmd = new SqlCommand("Select user_name, passwrd from regis_table", conn.con);
            try
            {
                SqlDataReader rd = cmd.ExecuteReader();
                dt.Load(rd);
                return dt;
            }
            catch (SqlException sqlex)
            {
                throw sqlex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
    }
}
