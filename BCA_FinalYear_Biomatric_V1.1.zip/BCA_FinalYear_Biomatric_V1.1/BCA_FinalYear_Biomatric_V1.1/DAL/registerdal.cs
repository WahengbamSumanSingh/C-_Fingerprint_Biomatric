﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using BCA_FinalYear_Biomatric_V1._1.DTO;

namespace BCA_FinalYear_Biomatric_V1._1.DAL
{
    public class registerdal
    {
        DataTable dt = new DataTable();
        connection conn = new connection();
        public string AddUser(registrationdto.user_profile aUser)
        {
            int insertId = 0;
            try
            {
                conn.con.Open();
                string sql = "INSERT INTO regis_table(first_name,last_name,gender,country,state,email,phone_no,user_name,passwrd)"
                + "VALUES(@firstname,@lastname,@gender,@country,@state,@email,@phone,@usr,@pass)";
                SqlCommand command = new SqlCommand(sql, conn.con);
                command.Parameters.AddWithValue("firstname", aUser.FirstName);
                command.Parameters.AddWithValue("lastname", aUser.LastName);
                command.Parameters.AddWithValue("gender", aUser.Gender);
                command.Parameters.AddWithValue("country", aUser.Country);
                command.Parameters.AddWithValue("state", aUser.State);
                command.Parameters.AddWithValue("email", aUser.Email);
                command.Parameters.AddWithValue("phone", aUser.Phone_Nos);
                command.Parameters.AddWithValue("usr", aUser.User_Name);
                command.Parameters.AddWithValue("pass", aUser.PassWord);
                insertId = command.ExecuteNonQuery();
                if (insertId > 0)
                {
                    return "success";
                }
                else
                {
                    return "Unknown error occured";
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
        public string UpdateUser(registrationdto.user_profile aUser)
        {
            int insertId = 0;
            try
            {
                conn.con.Open();
                SqlCommand command = new SqlCommand("UPDATE regis_table SET first_name = @firstname, last_name = @lastname, gender = @gender, country = @country" +
                "state = @state, email = @email, phone_no = @phone, user_name = @usr, passwrd = @pass WHERE ids = @id", conn.con);
                command.Parameters.AddWithValue("first_name", aUser.FirstName);
                command.Parameters.AddWithValue("lastname", aUser.LastName);
                command.Parameters.AddWithValue("gender", aUser.Gender);
                command.Parameters.AddWithValue("country", aUser.Country);
                command.Parameters.AddWithValue("state", aUser.State);
                command.Parameters.AddWithValue("email", aUser.Email);
                command.Parameters.AddWithValue("phone", aUser.Phone_Nos);
                command.Parameters.AddWithValue("usr", aUser.User_Name);
                command.Parameters.AddWithValue("pass", aUser.PassWord);
                command.Parameters.AddWithValue("id", aUser.Id);
                command.ExecuteNonQuery();
                if (insertId > 0)
                {
                    return "success";
                }
                else
                {
                    return "Unknown error occured";
                }

            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
        public void DeleteUsr(int deleteId)
        {

            try
            {
                conn.con.Open();
                SqlCommand command = new SqlCommand("DELETE FROM regis_table WHERE ids = @id", conn.con);
                command.Parameters.AddWithValue("id", deleteId);
                command.ExecuteNonQuery();
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn.con.State != ConnectionState.Closed)
                {
                    conn.con.Close();
                }
            }
        }
    }
}
