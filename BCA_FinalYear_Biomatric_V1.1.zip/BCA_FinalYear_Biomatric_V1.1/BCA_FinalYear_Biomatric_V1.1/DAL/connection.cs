﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace BCA_FinalYear_Biomatric_V1._1.DAL
{
    class connection
    {
        public SqlConnection con = new SqlConnection("Data Source=ROMITAYAKAIROL\\BIOMATRIC;Initial Catalog=biomatric;User ID=sa;Password=root");
    }
}
