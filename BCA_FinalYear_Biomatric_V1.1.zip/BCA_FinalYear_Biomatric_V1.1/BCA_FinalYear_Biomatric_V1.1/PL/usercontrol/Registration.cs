﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BCA_FinalYear_Biomatric_V1._1.DTO;
using BCA_FinalYear_Biomatric_V1._1.BLL;
using BCA_FinalYear_Biomatric_V1._1.PL.login;

namespace BCA_FinalYear_Biomatric_V1._1.PL.usercontrol
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }
        private void NewRegBtn_Click(object sender, EventArgs e)
        {
            string firstname = FirstNameTxBx.Text.Trim();
            string lastname = LastNameTxBx.Text.Trim();
            string gender = GenderComBx.Text.Trim();
            string country = CountryComBx.Text.Trim();
            string state = StateComBx.Text.Trim();
            string email = EmailTxBx.Text.Trim();
            string phone = PhonTxBx.Text.Trim();
            string usrname = UserTxBx.Text.Trim();
            string pass = NewPassTxBx.Text.Trim();
            string conpass = ConPassTxBx.Text.Trim();

            if (firstname == string.Empty || lastname == string.Empty || gender == string.Empty
                || country == string.Empty || state == string.Empty || email == string.Empty
                || phone == string.Empty || usrname == string.Empty || pass == string.Empty
                || conpass == string.Empty)
            {
                MessageBox.Show("Required fields cannot be empty");
                return;
            }
            if (RegCheckBx.Checked == false)
            {
                MessageBox.Show("Please Tick the license agrement");
                return;
            }
            if (pass != conpass)
            {
                MessageBox.Show("Confirm Password does not match with Password");
                return;
            }

            registrationdto.user_profile userdto = new registrationdto.user_profile();
            userdto.FirstName = firstname;
            userdto.LastName = lastname;
            userdto.Gender = gender;
            userdto.Country = country;
            userdto.State = state;
            userdto.Email = email;
            userdto.Phone_Nos = phone;
            userdto.User_Name = usrname;
            userdto.PassWord = pass;
            try
            {
                registerbll aUserBll = new registerbll();
                string AddUsrResult = aUserBll.AddUser(userdto);

                if (AddUsrResult != "success")
                {
                    MessageBox.Show("There is a problem on database");
                    return;
                }

                else
                {
                    MessageBox.Show("User Register Sucessfully");
                    return;
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login lgin = new Login();
            this.Hide();
            lgin.Show();
        }
    }
}
