﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BCA_FinalYear_Biomatric_V1._1.DTO;
using BCA_FinalYear_Biomatric_V1._1.BLL;
using BCA_FinalYear_Biomatric_V1._1.Driver;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace BCA_FinalYear_Biomatric_V1._1.PL.maincontrol
{
    public partial class Utilties : Form
    {
        private System.Net.Sockets.UdpClient UDPreceiver = new System.Net.Sockets.UdpClient(2000);
        string data = "";
        string dname = "";
        public Utilties()
        {
            InitializeComponent();
            UDPreceiver.Client.ReceiveTimeout = 1000;
            UDPreceiver.Client.Blocking = false;
        }

        private void configcombox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (configcombox.Text == "TCP")
            {
                tcpgroupbox.Visible = true;
            }
            else
                tcpgroupbox.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UDPreceiver.Close();          
            main mn = new main();           
            this.Hide();
            mn.Show();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string devicetype = devicetypecombx.Text.Trim();
            string connectiontype = contypecombx.Text.Trim();
            string configprotocol = configcombox.Text.Trim();
            string devicename = devicenametxbx.Text.Trim();
            string ip1 = ip1txbx.Text.Trim();
            string ip2 = ip2txbx.Text.Trim();
            string ip3 = ip3txbx.Text.Trim();
            string ip4 = ip4txbx.Text.Trim();
            string ipaddress = ip1 + '.' + ip2 + '.' + ip3 + '.' + ip4;
            string portstring = porttxbx.Text.Trim();
            int port = Int32.Parse(portstring);
            string companyprofile = companyprofiletxbx.Text.Trim();
            if (devicetype == string.Empty || connectiontype == string.Empty || configprotocol == string.Empty ||
               devicename == string.Empty || ip1 == string.Empty || ip2 == string.Empty || ip3 == string.Empty ||
               ip4 == string.Empty || portstring == string.Empty || companyprofile == string.Empty)
            {
                MessageBox.Show("Required fields cannot be empty");
                return;
            }
            
            devices_settingdto.device_setting dto = new devices_settingdto.device_setting();
            dto.DeviceType = devicetype;
            dto.ConnectionType = connectiontype;
            dto.ConfigProtocol = configprotocol;
            dto.DeviceName = devicename;
            dto.IpAddress = ipaddress;
            dto.Port = port;
            dto.CompanyProfile = companyprofile;
            try
            {
                device_settingbll dbll = new device_settingbll();
                string CheckdataRecurring = dbll.GetCheckdeviceRecurring(dto);
                if (CheckdataRecurring != "exist")
                {
                    string AddDeviceResult = dbll.AddDevice(dto);
                    if (AddDeviceResult != "success")
                    {
                        MessageBox.Show("There is a problem on database");
                        return;
                    }
                    else
                    {
                        MessageBox.Show("User Register Sucessfully");
                        
                        return;
                    }
                }
                else 
                {
                    MessageBox.Show("Device Name or Ip Address already exist");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return;
            }
            
        }
        private void KeyPresscheck(object sender, KeyPressEventArgs e)
        {
            // don't allow char
            if (!char.IsControl(e.KeyChar)
            && !char.IsDigit(e.KeyChar)
            && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // don't allow decimal point
            if (e.KeyChar == '.'
                && (sender as TextBox).Text.IndexOf('.') < 1)
            {
                e.Handled = true;
            }
            // restricting only three digit
            if ((sender as TextBox).Text.Count(Char.IsDigit) >= 3)
            {
                e.Handled = true;
            }
        }
        private void KeyPresscheckport(object sender, KeyPressEventArgs e)
        {
            // don't allow char
            if (!char.IsControl(e.KeyChar)
            && !char.IsDigit(e.KeyChar)
            && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // don't allow decimal point
            if (e.KeyChar == '.'
                && (sender as TextBox).Text.IndexOf('.') < 1)
            {
                e.Handled = true;
            }
            // restricting only three digit
            if ((sender as TextBox).Text.Count(Char.IsDigit) >= 4)
            {
                e.Handled = true;
            }
        }
        void fillDeviceIdsComboBox()
        {
            deviceIDEcombox.Items.Clear();
            device_settingbll dsbll = new device_settingbll();
            DataTable dt = dsbll.SelectOIds();
            int i = dt.Rows.Count;
            for (int j = 0; j < i;j++ )
            {
                deviceIDEcombox.Items.Add(dt.Rows[j][0].ToString().Trim());
            }
        }
        private void deviceIDEcombox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string data = deviceIDEcombox.Text.ToString().Trim();
            int dataid = Int32.Parse(data);
            devices_settingdto.device_setting dsetdto = new devices_settingdto.device_setting();
            device_settingbll dbll = new device_settingbll();
            DataTable dtdsbll = dbll.selectDevice(dataid);
            string datarow = dtdsbll.Rows[0][8].ToString();
            int datarowval = Int32.Parse(datarow) - 1;
            if (datarowval >= 0)
            {
                DeviceTypeETxBx.Text = dtdsbll.Rows[datarowval][1].ToString().Trim();
                ConnTypeETxBx.Text = dtdsbll.Rows[datarowval][2].ToString().Trim();
                ConfigProtocolETxBx.Text = dtdsbll.Rows[datarowval][3].ToString().Trim();
                DevicNameETxBx.Text = dtdsbll.Rows[datarowval][4].ToString().Trim();
                IpAddETxBx.Text = dtdsbll.Rows[datarowval][5].ToString().Trim();
                portETxBx.Text = dtdsbll.Rows[datarowval][6].ToString().Trim();
                ComProfilETxBx.Text = dtdsbll.Rows[datarowval][7].ToString().Trim();
            }
            else
            {
                MessageBox.Show("Database is Empty");
            }
        }

        private void deleteEBtn_Click(object sender, EventArgs e)
        {
            string data = deviceIDEcombox.Text.ToString().Trim();
            int dataid = Int32.Parse(data);
            device_settingbll dbll = new device_settingbll();
            dbll.deleteDevice(dataid);
            MessageBox.Show("Successfully Deleted");
            
        }

        private void Refreshbtn_Click(object sender, EventArgs e)
        {
            fillDeviceIdsComboBox();
        }

        private void updateEBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Unavailable at this moment");
        }

        private void checkConbtn_Click(object sender, EventArgs e)
        {
           //// //UDPreceiver.Close();
           ////// UDPreceiver.Client.Close();
            //if (deviceIDEcombox.Text.ToString() == null)
            //{
            //    MessageBox.Show("Please Select The ID for Testing");
            //}
            //int Ids = Int32.Parse(deviceIDEcombox.Text.ToString());
            //dsk11 driver1 = new dsk11();
            //string x = driver1.checkdsk11(Ids);
            //MessageBox.Show(x);
            //this.Refresh();
            MessageBox.Show("Unavailable at this moment");
        }

        private void uploadimgbtn_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "jpeg|*.jpg|bmp|*.bmp|all files|*.*";
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                useridpicbox.Image = Image.FromFile(openFileDialog1.FileName);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Byte[] ImageByteArray;
            Image img = useridpicbox.Image;
            Image _imgR = Resizes(img, 100, 100);
            Image _imgB = new Bitmap(_imgR);
            MemoryStream strm = new MemoryStream();
            _imgB.Save(strm,System.Drawing.Imaging.ImageFormat.Jpeg);
            ImageByteArray = strm.ToArray();
            string first_name = UBDFirstnametxbx.Text.Trim();
            string last_name = UBDLastNametxbx.Text.Trim();
            string per_add = UBDPerAddTxbx.Text.Trim();
            string cur_add = UBDCurrAddTxbx.Text.Trim();
            string user_ID = UBDUserIdTxbx.Text.Trim();
            string sdids = SelectDUSCombx.Text.ToString();
            int device_ID = Int32.Parse(sdids);
            if (first_name == string.Empty || last_name == string.Empty || per_add == string.Empty || cur_add == string.Empty || user_ID == string.Empty || sdids == string.Empty || checkBox1.Checked != true)
            {
                MessageBox.Show("Required fields are empty or Make sure you check the agrement");
            }
            else
            {
                UserBiodto userdto = new UserBiodto();
                userdto.UID = user_ID;
                userdto.fname = first_name;
                userdto.lname = last_name;
                userdto.curadd = cur_add;
                userdto.peradd = per_add;
                userdto.Uimg = ImageByteArray;
                userdto.devids = device_ID;
                try
                {
                    UserBiobll ubll = new UserBiobll();

                    string AddDeviceResult = ubll.AddUser(userdto);
                    if (AddDeviceResult != "success")
                    {
                        MessageBox.Show("There is a problem on database");
                        return;
                    }
                    else
                    {
                        MessageBox.Show("User Register Sucessfully");

                        return;
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    return;
                }
            }
        }
        private Image Resizes(Image img, int iWidth, int iHeight)
        {
            Bitmap bmp = new Bitmap(iWidth, iHeight);
            Graphics graphic = Graphics.FromImage((Image)bmp);
            graphic.DrawImage(img, 0, 0, iWidth, iHeight);
            return (Image)bmp;
        }

        private void enrollbtn_Click(object sender, EventArgs e)
        {
            try
            {
                UDPreceiver.BeginReceive(new AsyncCallback(recv), null);
                richTextBox1.Clear();
                UBDUserIdTxbx.Clear();
            }
            catch (Exception ex)
            {
                richTextBox1.Text += ex.Message.ToString();
            }

        }
        void recv(IAsyncResult res)
        {
            try
            {
                this.Invoke(new MethodInvoker(delegate { dname = SelectDUSCombx.Text.ToString(); }));
                UserBiobll ubll = new UserBiobll();
                DataTable dt = ubll.SelectIPFrmDeviceName(dname);
                string ipaddress = dt.Rows[0][0].ToString().Trim();
                int ports = Int32.Parse(dt.Rows[0][1].ToString().Trim());
                IPEndPoint RemoteIP = new IPEndPoint(IPAddress.Parse(ipaddress), ports);
                byte[] received = UDPreceiver.EndReceive(res, ref RemoteIP);
                data = Encoding.UTF8.GetString(received);
                this.Invoke(new MethodInvoker(delegate
                {

                    richTextBox1.Text += data;
                    UBDUserIdTxbx.Text = data;

                }));
                UDPreceiver.BeginReceive(new AsyncCallback(recv), null);
            }
            catch (Exception ex)
            {
                if (ex is ObjectDisposedException || ex is SocketException)
                {
                    return;
                }
                throw;
            }

        }

        

        private void RefreshUtiliesUsattingbtn_Click(object sender, EventArgs e)
        {
            fillDeviceNameComboBox();
        }
        void fillDeviceNameComboBox()
        {
            SelectDUSCombx.Items.Clear();

            UserBiobll ubll = new UserBiobll();
            DataTable dt = ubll.SelectOnlyDName();
            int i = dt.Rows.Count;
            for (int j = 0; j < i; j++)
            {
                SelectDUSCombx.Items.Add(dt.Rows[j][0].ToString().Trim());
            }
        }
    }
}
