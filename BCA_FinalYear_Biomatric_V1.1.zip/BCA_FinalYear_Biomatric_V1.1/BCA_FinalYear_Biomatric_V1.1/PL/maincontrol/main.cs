﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BCA_FinalYear_Biomatric_V1._1.BLL;
using System.Net;
using System.IO;
using BCA_FinalYear_Biomatric_V1._1.PL.login;
using System.Net.Sockets;
using BCA_FinalYear_Biomatric_V1._1.DTO;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;

namespace BCA_FinalYear_Biomatric_V1._1.PL.maincontrol
{
    public partial class main : Form
    {
        private System.Net.Sockets.UdpClient UDPreceiver = new System.Net.Sockets.UdpClient(2000);
        string data = "";
        string dname = "";
        public main()
        {
            InitializeComponent();
            UDPreceiver.Client.ReceiveTimeout = 1000;
            UDPreceiver.Client.Blocking = false;
            timer1.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UDPreceiver.Client.Close();
            Utilties ut = new Utilties();
            this.Hide();
            ut.Show();
        }

        private void main_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // performmmm
            try
            {
                UDPreceiver.BeginReceive(new AsyncCallback(recv), null);
                mainStdIDTxbx.Clear();
            }
            catch (Exception ex)
            {
                mainStdIDTxbx.Text += ex.Message.ToString();
            }
        }

        // recieve data
        void recv(IAsyncResult res)
        {
            try
            {
                this.Invoke(new MethodInvoker(delegate { dname = comboBox1.Text.ToString(); }));

                mainbll mbll = new mainbll();
                UserBiobll ubll = new UserBiobll();
                maindto.main_dto mandto = new maindto.main_dto(); 
                DataTable dt = ubll.SelectIPFrmDeviceName(dname);
                string ipaddress = dt.Rows[0][0].ToString().Trim();
                int ports = Int32.Parse(dt.Rows[0][1].ToString().Trim());
                IPEndPoint RemoteIP = new IPEndPoint(IPAddress.Parse(ipaddress), ports);
                byte[] received = UDPreceiver.EndReceive(res, ref RemoteIP);
                data = Encoding.UTF8.GetString(received);
                this.Invoke(new MethodInvoker(delegate
                {
                    mainStdIDTxbx.Text = data;
                    string s_data = comboBox1.Text.ToString().Trim();
                    int int_data = Int32.Parse(s_data);
                    DataTable ndt = mbll.SelectDevicesData(int_data, data.ToString().Trim());
                    if (ndt.Rows.Count == 0)
                    {
                        MessageBox.Show("Cannot identify the finger");
                    }
                    else
                    {
                        string user_id = ndt.Rows[0][0].ToString().Trim();
                        string f_name = ndt.Rows[0][1].ToString().Trim();
                        string l_name = ndt.Rows[0][2].ToString().Trim();
                        byte[] photo_array;
                        if (mainStdIDTxbx.Text.ToString().Trim() == user_id)
                        {
                            if (ndt.Rows[0][3] != System.DBNull.Value)
                            {
                                photo_array = (byte[])ndt.Rows[0][3];
                                MemoryStream ms = new MemoryStream(photo_array);
                                pictureBox2.Image = Image.FromStream(ms);
                            }
                            textBox1.Text = f_name + l_name;
                            TimeLbl.Text = clocklbl.Text.Trim().ToString();
                            mandto.Stu_name = textBox1.Text.ToString();
                            mandto.Stu_id = mainStdIDTxbx.Text.ToString();
                            mandto.dat_tim = TimeLbl.Text.ToString();
                            try 
                            {
                                string add_report_result = mbll.Add_report(mandto);
                                if (add_report_result != "success")
                                {
                                    MessageBox.Show("There is a problem on database");
                                    return;
                                }
                                else
                                {
                                    MessageBox.Show("Sucessfully");
                                    return;
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.ToString());
                                return;
                            }

                        }
                        else
                        {
                            MessageBox.Show("Unable to recognize the user");
                        }
                    }
                }));

                UDPreceiver.BeginReceive(new AsyncCallback(recv), null);
            }
            catch (Exception ex)
            {
                if (ex is ObjectDisposedException || ex is SocketException)
                {
                    return;
                }
                throw;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Refresh button
            fillDeviceIdsComboBox();
        }
        void fillDeviceIdsComboBox()
        {
            comboBox1.Items.Clear();
            device_settingbll dsbll = new device_settingbll();
            DataTable dt = dsbll.SelectOIds();
            int i = dt.Rows.Count;
            for (int j = 0; j < i; j++)
            {
                comboBox1.Items.Add(dt.Rows[j][0].ToString().Trim());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UDPreceiver.Client.Close();
            Login log = new Login();
            this.Hide();
            log.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;
            this.clocklbl.Text = dt.ToString();
        }

        private void generateReportBtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=ROMITAYAKAIROL\BIOMATRIC;Initial Catalog=biomatric;User ID=sa;Password=root");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from aten_db", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ReportDataSource rds = new ReportDataSource("DataSet1", dt);
            reportViewer1.LocalReport.ReportPath = @"C:\Users\pc\documents\visual studio 2010\Projects\BCA_FinalYear_Biomatric_V1.1\BCA_FinalYear_Biomatric_V1.1\Report\Report1.rdlc";
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(rds);
            reportViewer1.Refresh();
        }
        
    }
}
