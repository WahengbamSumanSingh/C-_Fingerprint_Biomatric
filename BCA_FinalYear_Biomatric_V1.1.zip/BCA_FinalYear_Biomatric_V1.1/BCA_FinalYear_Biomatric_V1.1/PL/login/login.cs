﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BCA_FinalYear_Biomatric_V1._1.BLL;
using BCA_FinalYear_Biomatric_V1._1.PL.usercontrol;
using BCA_FinalYear_Biomatric_V1._1.PL.helps;
using BCA_FinalYear_Biomatric_V1._1.PL.maincontrol;

namespace BCA_FinalYear_Biomatric_V1._1.PL.login
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        private void signupbtn_Click(object sender, EventArgs e)
        {
            Registration reg = new Registration();
            this.Hide();
            reg.ShowDialog();
        }

        private void signinbtn_Click_1(object sender, EventArgs e)
        {
            loginbll objbll = new loginbll();
            DataTable dt = objbll.GetLogin();
           // if ((usrtxbx.Text.Trim() == dt.Rows[0][0].ToString().Trim()) && (passtxbx.Text.Trim() == dt.Rows[0][1].ToString().Trim()))
            //{
                main mn = new main();
                this.Hide();
                mn.Show();
           // }
           // else
              //  MessageBox.Show("UserName or Password Incorrect");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            About ab = new About();
            this.Hide();
            ab.Show();
        }
    }
}
